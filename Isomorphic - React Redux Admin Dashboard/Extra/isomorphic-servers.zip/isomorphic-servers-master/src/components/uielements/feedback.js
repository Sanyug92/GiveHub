import { AutoComplete } from 'antd';

export default AutoComplete;
