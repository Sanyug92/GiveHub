import themedefault from './themedefault';
import theme2 from './theme2';

const themes = {
  themedefault,
  theme2
};
export default themes;
