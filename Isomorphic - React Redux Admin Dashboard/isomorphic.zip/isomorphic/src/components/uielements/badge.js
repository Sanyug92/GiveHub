import { Badge } from 'antd';

export default Badge;
