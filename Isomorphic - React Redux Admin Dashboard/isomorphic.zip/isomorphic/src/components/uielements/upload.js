import { Upload } from 'antd';

export default Upload;