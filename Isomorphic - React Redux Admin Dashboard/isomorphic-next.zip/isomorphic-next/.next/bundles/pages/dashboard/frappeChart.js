
          window.__NEXT_REGISTER_PAGE('/dashboard/frappeChart', function() {
            var comp = module.exports=webpackJsonp([119],{2124:function(o,t,e){o.exports=e(2125)},2125:function(o,t,e){"use strict"}},[2124]);
            return { page: comp.default }
          })
        