import Alerts from './alert.style';

export default Alerts;
