import { Breadcrumb } from 'antd';

export default Breadcrumb;