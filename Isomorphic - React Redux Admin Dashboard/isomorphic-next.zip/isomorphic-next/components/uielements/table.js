import { Table } from 'antd';
export default Table;
