import { Form } from 'antd';

export default Form;
