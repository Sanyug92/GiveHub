import React from 'react';

export default () => (
  <div className="isoContentLoader">
    <div className="loaderElement" />
  </div>
);
